// Michael Reilly
// I pledge my honor that I have abided by the Stevens Honor System.

const tvData = require('./tv');

module.exports = {
    tv: tvData
};