// Michael Reilly, 10439198, CS-546A
// I pledge my honor that I have abided by the Stevens Honor System.

// Based on lecture 5 data/index.js code

const showsData = require('./shows');

module.exports = {
    shows: showsData
};